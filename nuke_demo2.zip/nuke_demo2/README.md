
> 项目A线上链接 [example.com](https://example.com/)

## 项目介绍

项目简介及业务范围介绍


## 人员

人员列表

## 相关资料

- [PRD地址]()
- [视觉稿地址]()
- [数据接口约定]()
- [其他资料]()

## 开发环境依赖

- `nodejs`: ~4.4.0
- `fie`: ~2.0.0

## 本地开发

### hosts 绑定

```
127.0.0.1 example.taobao.com
127.0.0.1 api.example.taobao.com
```

### 开发调试


```

ding start

```

### 打包

```

ding build

```

## weex调试

```

http://nuke.taobao.org/nukedocs/guide/develop-tools.html

```

## 项目架构及目录结构介绍

介绍一下项目使用了哪些技术,及目录结构和技术架构说明

## 升级日志


### 0.0.1

@张全蛋

- 实现了XX功能
- 支持`websocket`通信
- ...


## 其他

### 注意点

- 什么地方需要注意

### TODO

- 后面可以做的优化的地方