'use strict';

import { createElement, render } from 'rax';

//1.待确认-预约信息页面
//import ToBeConfirmed from './container/toBeConfirmed.jsx';


//render(<ToBeConfirmed />);


//2.待评估-预约信息页面
//import ToBeAssessed from './container/toBeAssessed.jsx';


//render(<ToBeAssessed/>);


//3.待完成-预约信息页面

//import ToBeAccomplished from './container/toBeAccomplished.jsx';

//render(<ToBeAccomplished />);

//4.待评价-预约信息页面

//import ToBeEstimated from './container/toBeEstimated.jsx';

//render(<ToBeEstimated/>);


//5.已评价-预约信息页面
//import Estimated from './container/estimated.jsx';

//render(<Estimated/>);

//6.已取消-预约信息
import Canceled from './container/canceled.jsx';

render(<Canceled reason={"社区有我暂时不能提供此类服务"}/>);

