'use strict';
import {createElement, Component} from 'rax';
import {Text, View, Icon, Touchable} from 'weex-nuke';
import ServiceRequirement from './serviceRequirement.jsx';
import styles from './service.less';

const ICONS ={default:["arrowDown"]};
const serviceReqs = [
    {ID:'一',content:'赵大爷需要一个细心专业的保姆。',distribution:'陈红',price:'260'},
    {ID:'二',content:'赵大爷还需要理发服务。',distribution:'张芬芳',price:'20'}
]

class Service extends Component{
    constructor(props){
        super(props);
        this.state = {
            hided: false
        }
    }

    press = (e)=>{
        this.setState(previousState =>{
            return { hided: !previousState.hided};
        });
    }

    render(){
        return(
            <View style={styles.wrapper}>

                <View style={styles.textLine}>
                    <View style={styles.laebl}>
                        <Text style={styles.labelText}>服务主题</Text>
                    </View>
                    <View style={styles.result}>
                        <Text style={styles.resultText}>{this.props.serviceName}</Text>
                    </View>
                </View>

                <View style={styles.serReq}>
                    <Touchable style={styles.unTouch} activeStyle={styles.touch} onPress={this.press.bind(this)}>
                        <Text>查看更多信息</Text>
                        <Icon name={ICONS['default']}/>
                    </Touchable>
                    {
                        this.state.hided === true?
                        <View style={styles.hide}>
                            {
                                serviceReqs.map((item,index)=>{
                                return(
                                    <ServiceRequirement
                                        ID={item.ID}
                                        content={item.content}
                                        distribution={item.distribution}
                                        price={item.price}>
                                    </ServiceRequirement>
                                )
                            })
                            }
                            
                        </View>
                        :null
                    }
                    
                </View>

            </View>
        );
    }
}

export default Service;