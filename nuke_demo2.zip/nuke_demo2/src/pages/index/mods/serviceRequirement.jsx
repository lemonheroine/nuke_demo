'use strict';
import {createElement, Component} from 'rax';
import {View, Text} from 'weex-nuke';
import styles from './serviceRequirement.less';


class ServiceRequirement extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            
            <View style={styles.wrapper}>
                <View style={styles.textLine}>
                    <Text style={styles.title}>服务需求{this.props.ID}</Text>
                </View>

                <View style={styles.textLine}>
                    <Text style={styles.content}>{this.props.content}</Text>
                </View>

                <View style={styles.textLine}>
                    <View style={styles.label}>
                        <Text style={styles.labelText}>分配</Text>
                    </View>
                    <View style={styles.result}>
                        <Text style={styles.resultText}>{this.props.distribution}</Text>
                    </View>
                </View>

                <View style={styles.textLine}>
                    <View style={styles.label}>
                        <Text style={styles.labelText}>服务价格</Text>
                    </View>
                    <View style={styles.result}>
                        <Text style={styles.resultText}>{this.props.price}元</Text>
                    </View>
                </View>
            </View>
        );
    }
}

export default ServiceRequirement;