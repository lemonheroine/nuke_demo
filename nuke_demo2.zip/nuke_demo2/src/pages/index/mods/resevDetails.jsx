'use strict';
import { createElement, Component} from 'rax';
import { Text, Input, Image, Grid,Col,View,Touchable} from 'weex-nuke';
import styles from './resevDetails.less';

const SRC ={default:["../container/photos/call.svg"]};

class ResevDetails extends Component{
    constructor(props){
        super(props);
    }

    render(){ 
        return(
            <Grid  style={styles.wrapper}>
                
                <View style={styles.textLine}>
                    <View style={styles.label}>
                        <Text style={styles.labelText}>预约业主姓名</Text>
                    </View>
                    <View style={styles.result}>
                        <Text style={styles.resultText}>{this.props.username}</Text>
                    </View>
                </View>

                <View style={styles.textLine}>
                    <View style={styles.label}>
                        <Text style={styles.labelText}>上门服务地址</Text>
                    </View>
                    <View style={styles.result}>
                        <Text style={styles.resultText}>{this.props.address}</Text>
                    </View>
                </View>

                <View style={styles.textLine}>
                    <View style={styles.label}> 
                        <Text style={styles.labelText}>联系人手机号</Text>
                    </View>
                    <View style={styles.result}>
                        <Text style={styles.resultText}>{this.props.phone}</Text>
                    </View>
                    
                    <View style={styles.phone} >
                        <Touchable style={styles.phoneTouch}>
                            <Image  style={styles.phoneImage} source={require("image-source-loader!../photos/call.svg")}/>
                        </Touchable>
                    </View>
                </View>

                <View style={styles.textLine}>
                    <View style={styles.label}>
                        <Text style={styles.labelText}>第二联系人</Text>
                    </View>
                    <View style={styles.result}>
                        <Text style={styles.resultText}>{this.props.secphone}</Text>
                    </View>
                    <View style={styles.relation}>
                        <Text style={styles.relationText}>{this.props.relation}</Text>
                    </View>
                </View>

            </Grid>
        );
    }
}

export default ResevDetails;