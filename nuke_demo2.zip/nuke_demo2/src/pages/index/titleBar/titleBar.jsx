'use strict';
import {createElement, Component} from 'rax';
import {View,Text,Button,Env,Grid,Col,Icon,MultiRow} from 'weex-nuke';


class TitleBar extends Component{
    constructor(props){
        super(props);

    }

    render(){
        return(
            <View>
                <Grid style={{height:'100rem'}}>
                <Col style={{justifyContent:'center',alignments:'center'}}>
                    <Icon src={this.props.source}/>
                </Col>
                <Col style={styles.title}>
                    <Text style={styles.titleText}>{this.props.title}</Text>
                </Col>
                <Col style={styles.rightCom}>
                    <Text>{this.props.rightCom}</Text>
                </Col>
                </Grid>
            </View>
        );
    }
}

const styles = {
    icon:{
        fontSize:40
    },
    title:{
        justifyContent:'center',
        alignItems:'center',
        background:'red',
        height:'100rem'
    },
    rightCom:{
        justifyContent:'center',
        alignItems:'center',
        background:'green'
    },
    titleText:{
        fontSize:40,
        justifyContent:'center',
        alignItems:'center',
        padding:'20rem',
    },
    rightText:{
        marginTop:'20rem',
        fontSize:30
    }
}


export default TitleBar;
