'use strict';

import { createElement, Component} from 'rax';
import {Text, Image, Touchable, View} from 'weex-nuke';
import ResevDetails from '../mods/resevDetails.jsx';
import reducers from '../redux/reducers/index.js';
import createStore from '../redux/store/index.js';
import Service from '../mods/service.jsx';
import dingtalk from 'dingtalk-javascript-sdk';
import { Provider } from 'rax-redux';
import styles from './estimated.less';

const store = createStore(reducers);
class Estimated extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <Provider store={store}>
                <View style={styles.content}>
                <View style={styles.wrapper}>

                        <View style={styles.resev}>
                            <ResevDetails 
                                username={"赵晓光"} 
                                address={"天津市南开区竹苑路嘉兴里11号楼1门102"} 
                                phone={"18622326330"} 
                                secphone={"13802325221"}
                                relation={"父母"}>
                            </ResevDetails>
                        </View>

                        <View style={styles.service}>
                        <Service 
                                serviceName={"保姆理发"}>

                        </Service>
                        </View>

                        <View style={styles.textLine}>
                            <View style={styles.label}>
                                <Text style={styles.labelText}>支付方式</Text>
                            </View>
                            <View style={styles.result}>
                                <Text style={styles.resultText}>支付宝</Text>
                            </View>
                        </View>

                    </View>
                </View>
            </Provider>
        );
    }
}

export default Estimated;