'use strict';

import { createElement, Component } from 'rax';
import { View ,Icon} from 'weex-nuke';
import { connect } from 'rax-redux';
import AddItem from '../mods/addItem.jsx';
import ResevDetails from '../mods/resevDetails.jsx';
import List from '../mods/list.jsx';
import { modifyItem, addItem } from '../redux/actions/todo.js';
import styles from './main.less';


/*

class Todo extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  modifyItem = (index) => {
    this.props.dispatch(modifyItem(index));
  }
  addItem = (obj) => {
    this.props.dispatch(addItem(obj));
  }
  render() {
    return (
      <View style={styles.container}>
        <AddItem addItem={this.addItem} />
        <List dataSource={this.props.todoMVC} modifyItem={this.modifyItem} style={styles.list} />
      </View>
    );
  }
}

function mapStateToProps(state) {
  return {
    todoMVC: state.todoReducer,
  };
}

export default connect(mapStateToProps)(Todo);


*/


class Todo extends Component{
  constructor(props){
    super(props);

  }

  render(){
    return(
      <View>
        <ResevDetails username={"赵晓光"} address={"天津市南开区竹苑路嘉兴里11号楼1门102"} phone={"18622326330"} secphone={"13802325221"}/>
      </View>
    );
  }

}

export default Todo; 

