/**
 * 全局设置  local 日常  production  线上和预发
 */
export default {
  env: 'production'
}
