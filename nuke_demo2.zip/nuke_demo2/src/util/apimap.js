'use strict';

const local = {
  'theme.list.get.info': {
    type: 'jsonp',
    value: 'http://easy-mock.com/mock/5954c9509adc231f356da90e/example/mock'
  },
};
const product = {
  'nuke.demo.interface.get': {        //fetch请求
    type: 'jsonp',
    value: 'http://easy-mock.com/mock/5954c9509adc231f356da90e/example/mock'
  },
};
export {
  local,
  product,
};
